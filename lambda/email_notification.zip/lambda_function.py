from email_notifications_utils import *
from prettytable import PrettyTable

def lambda_handler(event, context):

    # Start Message Body
    message_body = ""
    # get items to be emailed
    to_email_items = getSnapshotRecords("emailed")
    deleted_items = getSnapshotRecords("deleted")

    # Check to see if there are any new snapshots to be delivered
    if to_email_items.__len__() != 0:

        # Add to logger
        logger.info("Found {} record(s) to be emailed".format(to_email_items.__len__()))

        # Start Snapshots Table
        new_snapshots_table = PrettyTable(['Snapshot ID', 'RDS Name', 'Snapshot State'])

        # Align content to the left side
        new_snapshots_table.align = 'l'

        # Add snapshots to New Snapshots Table
        for item in to_email_items:

            if item["Snapshot_State"]["S"] != "deleted" and item["Snapshot_State"]["S"] != "not found":
                new_snapshots_table.add_row([item["Snapshot_ID"]["S"],item["RDS_Name"]["S"],item["Snapshot_State"]["S"]])

        # Add header and New Snapshots Table to Message Body
        message_body += "New Snapshots\n"
        message_body += str(new_snapshots_table)
        message_body += "\n\n"
    else:
        logger.info("No new snapshots found")
        message_body += "No new snapshots found\n"


    # Check to see if there are any snapshots that have been deleted recently
    if deleted_items.__len__() != 0:

        # Add to logger
        logger.info("Found {} record(s) to be deleted from DynamoDB".format(deleted_items.__len__()))

        deleted_snapshots_table = PrettyTable(['Snapshot ID', 'RDS Name'])
        deleted_snapshots_table.align = "l"

        # Add snapshots to Deleted Snapshots Table
        for item in deleted_items:
            deleted_snapshots_table.add_row([item["Snapshot_ID"]["S"],item["RDS_Name"]["S"]])

        # Add header for Deleted Snapshot Table to Message Body
        message_body += "Deleted Snapshots\n"
        message_body += str(deleted_snapshots_table)
    else:
        logger.info("No recent deleted snapshots found")
        message_body += "No recent deleted snapshots found\n"



    # Publish to SNS and get response
    logger.debug(message_body)
    resp = publishToSNS(message_body)
    logger.info(resp)

    # Check if we got a message ID and clean up DynamoDB
    if resp['MessageId'] != '':
        # Add to logger
        logger.info("Publish successfully, Message ID: {}".format(resp['MessageId']))

        # Update DynamoDB Table
        for item in to_email_items:
            logger.info("Updating record {} - {} with email state {}".format(item["Snapshot_ID"]["S"],item["RDS_Name"]["S"],item["Snapshot_State"]["S"]))
            manageSnapshotRecord(action = 'update', snapshot_id = item["Snapshot_ID"]["S"], rds_name = item["RDS_Name"]["S"], emailed_bool = True)
        
        # Delete records for deleted snapshots
        for item in deleted_items:
            logger.info("Removing DynamoDB Record: {} - {}".format(item["Snapshot_ID"]["S"], item["RDS_Name"]["S"]))
            delSnapshotRecord(item["Snapshot_ID"]["S"], item["RDS_Name"]["S"])

if __name__ == '__main__':
    lambda_handler(None, None)